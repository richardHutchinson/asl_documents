class CreateNewMovies < ActiveRecord::Migration
  def change
    create_table :new_movies do |t|

      t.timestamps
    end
  end
end
