class CreateSearchMovies < ActiveRecord::Migration
  def change
    create_table :search_movies do |t|

      t.timestamps
    end
  end
end
