class Movie < ActiveRecord::Base
  attr_accessible :movie_id, :name, :imdb_id, :url, :tagline, :certification, :overview, :released, :runtime, :poster_thumb, :poster_cover, :poster_w154, :poster_w342, :backdrop_poster, :user_id, :date_added
end
