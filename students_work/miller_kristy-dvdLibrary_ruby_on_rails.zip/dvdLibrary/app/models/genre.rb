class Genre < ActiveRecord::Base
  attr_accessible :genre_id, :movie_id, :genre
end