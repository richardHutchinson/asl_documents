class ConfirmAddController < ApplicationController
  def index

    @id = params[:id]

    require 'rubygems'
    require 'ruby-tmdb'

    # setup your API key
    Tmdb.api_key = "25ef7a17f865553a28f09aab4124a8ac"

    # setup your default language
    Tmdb.default_language = "en" 

    response = TmdbMovie.find(:id => @id)
    results = ActiveSupport::JSON.encode(response)
    movie = ActiveSupport::JSON.decode(results)

    @m = movie["table"]

  end

  def confirm
    id = params[:id]

    # setup your API key
    Tmdb.api_key = "25ef7a17f865553a28f09aab4124a8ac"

    # setup your default language
    Tmdb.default_language = "en" 

    response = TmdbMovie.find(:id => id)
    results = ActiveSupport::JSON.encode(response)
    movie = ActiveSupport::JSON.decode(results)

    m = movie["table"]

    date_added = Time.now

    puts session[:user_id]


    movie = Movie.create("movie_id" => m.fetch("id"),
                         "name" => m.fetch("name"),
                         "imdb_id" => m.fetch("imdb_id"),
                         "url" => m.fetch("url"),
                         "tagline" => m.fetch("tagline"),
                         "certification" => m.fetch("certification"),
                         "overview" => m.fetch("overview"),
                         "released" => m.fetch("released"),
                         "runtime" => m.fetch("runtime"),
                         "poster_thumb" => m.fetch("posters")[0]["table"]["url"],
                         "poster_cover" => m.fetch("posters")[2]["table"]["url"],
                         "poster_w154" => m.fetch("posters")[1]["table"]["url"],
                         "poster_w342" => m.fetch("posters")[3]["table"]["url"],
                         "backdrop_poster" => m.fetch("backdrops")[1]["table"]["url"],
                         "user_id" => session[:user_id],
                         "date_added" => date_added)

    redirect_to :controller => "home", :action => "index"
  end


end
