class MovieController < ApplicationController
  def index
    @response = Movie.find(params[:id])

    # Formatted release date
    @response["released"] = @response["released"].split("-")[1] + "/" + @response["released"].split("-")[2] + "/" + @response["released"].split("-")[0]

   case @response["certification"]
	  when "PG"
	    @response["certification"] = "rated_pg.png"
	  when "G"
	    @response["certification"] = "rated_g.png"
	  when "PG-13"
	    @response["certification"] = "rated_pg_13.png"
	  when "R"
	    @response["certification"] = "rated_r.png"
	  when ""
	    @response["certification"] = "rated_nr.png"
	end

  end


  def delete
    Movie.find(params[:id]).destroy
    redirect_to :controller => "home", :action => "index"
  end
end
