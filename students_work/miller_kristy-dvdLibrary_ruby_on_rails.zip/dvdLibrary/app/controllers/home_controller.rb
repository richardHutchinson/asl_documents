class HomeController < ApplicationController
  def index
    @results = Movie.where(:user_id => session[:user_id]).order("date_added DESC")
  end

  def sort
  	@change = []

    if params["selection"] == "A-Z"
    	@change = ["ascending"]
    elsif params["selection"] == "Z-A"
    	@change = ["decending"]
    elsif params["selection"] == "Recently Added"
    	@change = ["recently_added"]
    end

    respond_to do |format|
	     format.js { render :json => @change }
	  end
  end

  def ascending
    @change = Movie.where(:user_id => session[:user_id]).order("name ASC")
  end

  def decending
    @change = Movie.where(:user_id => session[:user_id]).order("name DESC")
  end

end
