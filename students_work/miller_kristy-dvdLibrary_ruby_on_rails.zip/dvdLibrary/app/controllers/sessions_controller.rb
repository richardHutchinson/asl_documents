class SessionsController < ApplicationController
	def logout
		session[:user_id] = nil
		redirect_to :controller => "landing", :action => "index"
	end
end
