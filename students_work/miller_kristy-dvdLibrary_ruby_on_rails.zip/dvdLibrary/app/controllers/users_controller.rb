class UsersController < ApplicationController
  def new
  	@user = User.new
  end

	def create
		

		@user = User.new(params[:user])
		
		if @user.save
			puts "here"
			user = User.find_by_email(params[:user]["email"])
			session[:user_id] = user.user_id

			flash[:notice] = "You Signed up successfully"
			flash[:color]= "valid"
			 redirect_to(:controller => "home", :action => 'index')
		else
			flash[:notice] = "Form is invalid"
			flash[:color]= "invalid"
			render "new"
		end
	end
end
