require 'rubygems'

class SearchMoviesController < ApplicationController

  	def index

  	end


  	def search

        search_terms =  params["search"]

        require 'rubygems'
        require 'ruby-tmdb'

        # setup your API key
        Tmdb.api_key = "25ef7a17f865553a28f09aab4124a8ac"

        # setup your default language
        Tmdb.default_language = "en" 

        response = TmdbMovie.find(:title => search_terms, :limit => 10, :expand_results => true)
        results = ActiveSupport::JSON.encode(response)
        @movies = ActiveSupport::JSON.decode(results)

    end # end of search function

end
