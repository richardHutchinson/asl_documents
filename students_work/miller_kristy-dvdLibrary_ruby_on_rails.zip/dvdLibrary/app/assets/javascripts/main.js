$(document).ready(function(){

	var sortBy = $("#sort");

	var displaySort = function(data){
		data = JSON.parse(data);
		var d = data[0];

		switch(d){
			case "ascending":
				window.location.replace("../home/ascending");
				break;
			case "decending":
				window.location.replace("../home/decending");
				break;
			default:
				window.location.replace("../home/index");
		}
	};

	sortBy.change(function(e){
		$("#sort option:selected").each(function(){
			var selection = $(this);


			$.ajax({
			    type: 'POST',
			    url: "../home/sort",
			    beforeSend: function(xhr) {xhr.setRequestHeader('X-CSRF-Token', $('meta[name="csrf-token"]').attr('content'))},
			    data: {
			    	selection: selection.val()
			    },
			    success: function(data){
			    	displaySort(data);
			    },
			    error: function(xhr, status, error){
			    	console.log(xhr);
			    	console.log(status);
			    	console.log(error);
			    }
			});
		});
	});


}); // End