$(document).ready(function(){


	var sortBy = $("#sort");

	var displaySort = function(data){
		data = JSON.parse(data);
		var d = data[0];

		switch(d){
			case "ascending":
				window.location.replace("../home/ascending");
				break;
			case "decending":
				window.location.replace("../home/decending");
				break;
			default:
				window.location.replace("../home/index");
		}
	};


	// var displaySearchResults = function(data){
	// 	data = JSON.parse(data);
	// 	var searchResultsBox = $(".search-results");
	// 	searchResultsBox.css("display", "block");

	// 	$(".results").css("display", "block");
	// 	$(".search").css("height", "100%");

	// 	h

	// 	$(data).each(function(i, v){

	// 		// Need help with figuring out path for no image
	// 		if(v.table.posters.length <= 0){
	// 			container.append('<div class="dvd-results"><p class="dvd-poster" data-id="' + v.table.id + '"><a href="#">No Image</a></p><p class="dvd-title">' + v.table.name + '</p></div>');
	// 		}else if(v.table.released === null){
	// 			container.append('<div class="dvd-results"><p class="dvd-poster" data-id="' + v.table.id + '"><a href="#"><img src="'+ v.table.posters[0].table.url + '"/></a></p><p class="dvd-title">' + v.table.name + '</p></div>');
	// 		}else{
	// 			container.append('<div class="dvd-results"><p class="dvd-poster" data-id="' + v.table.id + '"><a href="#"><img src="'+ v.table.posters[0].table.url + '"/></a></p><p class="dvd-title">' + v.table.name + '</p><p class="dvd-released">' + v.table.released + '</p></div>');
	// 		}

	// 	})

	// 	searchResultsBox.html(container);

	// 	$(".dvd-poster").click(function(e){
	// 		movieID = $(this).attr("data-id");

	// 		$.ajax({
	// 		    type: 'POST',
	// 		    url: "../confirm_add/index",
	// 		    beforeSend: function(xhr) {xhr.setRequestHeader('X-CSRF-Token', $('meta[name="csrf-token"]').attr('content'))},
	// 		    data: {
	// 		    	movieID: movieID
	// 		    },
	// 		    success: function(data){
	// 		    	console.log(data43dX);
	// 		    	// window.location.replace("../confirm_add/load_movie/");
	// 		    },
	// 		    error: function(xhr, status, error){
	// 		    	console.log(xhr);
	// 		    	console.log(status);
	// 		    	console.log(error);
	// 		    }
	// 		});

	// 		return false;
	// 	});
	// };





	sortBy.change(function(e){
		$("#sort option:selected").each(function(){
			var selection = $(this);


			$.ajax({
			    type: 'POST',
			    url: "../home/sort",
			    beforeSend: function(xhr) {xhr.setRequestHeader('X-CSRF-Token', $('meta[name="csrf-token"]').attr('content'))},
			    data: {
			    	selection: selection.val()
			    },
			    success: function(data){
			    	displaySort(data);
			    },
			    error: function(xhr, status, error){
			    	console.log(xhr);
			    	console.log(status);
			    	console.log(error);
			    }
			});
		});
	});






	// var searchBtn = $(".search-btn");

	// searchBtn.click(function(e){
	// 	var searchTerms = $(".search-terms").val();

	// 	$.ajax({
	// 	    type: 'POST',
	// 	    url: "../search_movies/index",
	// 	    beforeSend: function(xhr) {xhr.setRequestHeader('X-CSRF-Token', $('meta[name="csrf-token"]').attr('content'))},
	// 	    data: {
	// 	    	searchTerms: searchTerms
	// 	    },
	// 	    success: function(data){
	// 	    	displaySearchResults(data);
	// 	    },
	// 	    error: function(xhr, status, error){
	// 	    	console.log(xhr);
	// 	    	console.log(status);
	// 	    	console.log(error);
	// 	    }
	// 	});




	// 	return false;
	// });









}); // End