require 'test_helper'

class UserHomeHelperTest < ActionView::TestCase
end
