require 'test_helper'

class LandingHelperTest < ActionView::TestCase
end
