require 'test_helper'

class NewCollectionHelperTest < ActionView::TestCase
end
