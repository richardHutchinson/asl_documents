require 'test_helper'

class ConfirmAddHelperTest < ActionView::TestCase
end
