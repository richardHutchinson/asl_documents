require 'test_helper'

class SearchMoviesHelperTest < ActionView::TestCase
end
