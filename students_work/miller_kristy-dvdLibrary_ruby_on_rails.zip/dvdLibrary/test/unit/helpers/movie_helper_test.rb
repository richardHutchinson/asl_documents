require 'test_helper'

class MovieHelperTest < ActionView::TestCase
end
