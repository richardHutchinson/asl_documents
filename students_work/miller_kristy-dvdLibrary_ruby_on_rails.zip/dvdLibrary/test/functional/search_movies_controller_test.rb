require 'test_helper'

class SearchMoviesControllerTest < ActionController::TestCase
  test "should get index" do
    get :index
    assert_response :success
  end

end
