# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
DvdLibrary::Application.config.secret_token = '80c8827ee9b803b6618e5eb55946657b0ec935a2fc51a374961e5d69582e9fc3a44bdd93b421129064add8886835f70b1c6423ec4c7e57153c01b6f6c62aaa08'
